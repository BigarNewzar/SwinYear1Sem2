﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swin_Adventure
{
    public class MoveCommand:Command
    {
        public MoveCommand() : base(new string[] { "move", "go", "head", "leave" })
        {
        }
        public override string Execute(Player player, string[] text)
        {
			string response = "";
			// Check whether text is a valid length
			if (text.Length > 2 || text.Length == 0)
            {
				response += "I don't know how to move like that.";
				
            }

			//
			if (text.Length == 2 && ((text[0] == "move") || (text[0] == "go") || (text[0] == "head")) || (text[0] == "leave"))
			{
				if (player.Location.Path.AreYou(text[1]))
				{
					//for setting the only successful exit location in the SwinAdventure game world
					if (player.Location.Path.Location == null)
					{
						response += "You have escaped the SwinAdventure game! Well Done!";
					}
					//following the syntax given in requirements page 
					else
					{
						response += "You head " + text[1] + "\n" + player.Location.Path.Pathtext;
						player.Location.Path.Move(player, text[1]);
						response += "\nYou have arrived in " + player.Location.Name;
					}
				}
				else
				{
					return "Error for direction " + text[1] +"\nDirection is Invalid";
				}
			}
			else 
			{
				return "Error in move command";
			}
			
			return response;
		}
    }
}
