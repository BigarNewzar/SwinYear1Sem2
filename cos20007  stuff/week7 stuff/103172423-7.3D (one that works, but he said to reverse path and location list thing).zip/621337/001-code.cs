﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Swin_Adventure;

namespace NUnitTests
{
	[TestFixture()]
	public class TestPath
	{
		public Location smallcloset;
		public Path hallway_path;
		public Location hallway;
		public Player player;
		public List<Location> locationlist;
		public MoveCommand move;
		public Direction[] directionSouth;


		[SetUp]
        public void Setup()
        {
			smallcloset = new Location(new String[] { "small closet" }, "small closet",
												"A small dark closet, with an odd smell");
			directionSouth = new Direction[] { Direction.South };
			hallway_path = new Path(new String[] { "hallway", "South", }, smallcloset,
										 "You go through a door.", directionSouth);
			hallway = new Location(new String[] { "hallway", "long hallway" }, "hallway",
											"This is a long well lit hallway");

			player = new Player("me", "mighty programmer");
			move = new MoveCommand();

			//since using property to set those stuff instead of changing the contructor for the player or location,
			//must assign those properties from the start.
			//or else program will scream : NULL REFERENCE ERROR!
			player.Location = hallway;
			hallway.Path = hallway_path;


		}
		[Test()]
		public void TestMovePlayerToDestination()
		{
					
			hallway_path.Move(player, "South");
			Assert.AreEqual(smallcloset, player.Location);
		}

		[Test()]
		public void TestGetPathFromLocation()
		{
			
			Assert.IsInstanceOf<Path>(player.Location.Path);
		}

		[Test()]
		public void TestValidPathIdentifier()
		{
		//adding hallway and smallcloset to the list of location
		locationlist = new List<Location>();
		locationlist.Add(hallway);
		locationlist.Add(smallcloset);


			
		

			string[] StringToSubstring(string text)
			{
				char delimiterChar = ' ';// space will be used to seperate them
				return text.Split(delimiterChar);// split will split the string into substrings
			}


			Assert.AreEqual("You head south\nYou go through a door.\nYou have arrived in small closet", move.Execute(player, StringToSubstring("move south")));
		}

		[Test()]
		public void InvalidPathIdentifier()
		{

			string[] StringToSubstring(string text)
			{
				char delimiterChar = ' ';// space will be used to seperate them
				return text.Split(delimiterChar);// split will split the string into substrings
			}
			
			

			Assert.AreEqual("Error in move command", move.Execute(player, StringToSubstring("mov downwards")));
		}
	}
}
