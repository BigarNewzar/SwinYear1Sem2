﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swin_Adventure
{
    public class Path:IdentifiableObject
    {
        private Location _location;
        private string _pathtext;
        private string[] _id;
        private Direction[] _direction;
    

	public Path(string[] id, Location location, string pathtext, Direction[] direction) : base(id)
	{
		_location = location;
		_id = id;
		_pathtext = pathtext;
		_direction = direction;
	}

	public string Pathtext
	{
		get
		{
			return _pathtext;
		}
	}

	public string Direction
	{
		get
		{
			string direction = "";
			direction += "\nThere are exits to the ";
			if (_direction.Length > 1)
			{
				direction += " and " + _direction;
			}
			else
			{
				direction += _direction[0].ToString();

			}
			return direction;
		}

	}

		public string[] Id
		{
			get
			{
				return _id;
			}
		}

		public Location Location
		{
			get
			{
				return _location;
			}
		}

	public void Move(Player player, string direction)
	{	//valid path so player can leave
		if (player.Location.Path._direction[0].ToString().ToLower() == direction.ToLower())
		{
			player.Location = Location;
		}
		else
		{
				//all other paths invalid, so stay in location

				foreach (Location location in player.Locationlist)
			{
				if (player.Location.Path._id[1].ToLower() == location.Name.ToLower())
				{
					player.Location = location;
				}
			}
		}


	}

	}
}


